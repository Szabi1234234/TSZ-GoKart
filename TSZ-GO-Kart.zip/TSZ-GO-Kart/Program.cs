﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace GokartFoglalo
{

    class Helyszin
    {
        public string Nev;
        public string Cim;
        public string Telefon;
        public string Weboldal;
    }

    class Versenyzo
    {
        public string Vezeteknev;
        public string Keresztnev;
        public DateTime SzuletesiIdo;
        public bool Elmult18;
        public string Azonosito;
        public string Email;

        public DateTime FoglalasNap;
        public int FoglalasKezdes;
        public int FoglalasHossz;

        public bool Foglalt
        {
            get { return FoglalasKezdes >= 0; }
        }

        public string TeljesNev
        {
            get { return Vezeteknev + " " + Keresztnev; }
        }

        public string FoglalasSzoveg
        {
            get
            {
                if (!Foglalt) return "-";
                return FoglalasNap.ToString("yyyy.MM.dd") + " " + FoglalasKezdes + "-" + (FoglalasKezdes + FoglalasHossz);
            }
        }

        public Versenyzo(string vezeteknev, string keresztnev, DateTime szuletes)
        {
            Vezeteknev = vezeteknev;
            Keresztnev = keresztnev;
            SzuletesiIdo = szuletes;
            FoglalasKezdes = -1;
            FoglalasHossz = 0;

            Elmult18 = szuletes.AddYears(18) <= DateTime.Today;

            string nevEkezetNelkul = Ekezettelenit(vezeteknev) + Ekezettelenit(keresztnev);
            Azonosito = "GO-" + nevEkezetNelkul + "-" + szuletes.ToString("yyyyMMdd");

            Email = (Ekezettelenit(vezeteknev) + "." + Ekezettelenit(keresztnev)).ToLower() + "@gmail.com";
        }

        private static string Ekezettelenit(string szoveg)
        {
            string bontott = szoveg.Normalize(NormalizationForm.FormD);
            StringBuilder sb = new StringBuilder();
            foreach (char c in bontott)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }
            return sb.ToString().Normalize(NormalizationForm.FormC)
                     .Replace(" ", "").Replace("-", "");
        }
    }

    class Program
    {
        const string PROJEKT_NEV = "Gokart";
        const string KESZITO = "Tóth Szabolcs";
        const string KEZDO_DATUM = "2026.09.21.";

        const int NYITAS = 8;
        const int ZARAS = 19;
        const int MIN_LETSZAM = 8;
        const int MAX_LETSZAM = 20;
        const int MIN_ORA = 1;
        const int MAX_ORA = 2;

        const int CELLA_SZELESSEG = 5;
        const bool LETSZAM_KIIRAS = true;

        static Random rnd = new Random();

        static Dictionary<DateTime, List<Versenyzo>[]> naptar = new Dictionary<DateTime, List<Versenyzo>[]>();
        static List<DateTime> napok = new List<DateTime>();

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Fejlec();


            Helyszin palya = new Helyszin();
            palya.Nev = "TSZ Gokartpálya";
            palya.Cim = "2500 Esztergom, Ring utca 8.";
            palya.Telefon = "+36-30-555-0142";
            palya.Weboldal = "tsz-gokart.hu";
            HelyszinKiir(palya);


            List<string> vezeteknevek = NevekBeolvas("vezeteknevek.txt");
            List<string> keresztnevek = NevekBeolvas("keresztnevek.txt");

            int db = rnd.Next(1, 151);
            List<Versenyzo> versenyzok = new List<Versenyzo>();
            for (int i = 0; i < db; i++)
                versenyzok.Add(VersenyzoGeneral(vezeteknevek, keresztnevek));

            Console.WriteLine("\nElkészült " + db + " versenyzőprofil.");


            NaptarLetrehoz();

            bool fut = true;
            while (fut)
            {
                Console.WriteLine("\n============= FŐMENÜ =============");
                Console.WriteLine(" 1 - Versenyzők adatai");
                Console.WriteLine(" 2 - Foglalási naptár (időszalag)");
                Console.WriteLine(" 3 - Új foglalás");
                Console.WriteLine(" 4 - Meglévő foglalás módosítása");
                Console.WriteLine(" 5 - Foglalás lemondása");
                Console.WriteLine(" 6 - Próbaadatok generálása");
                Console.WriteLine(" 0 - Kilépés");
                Console.Write("Választás: ");

                string valasz = (Console.ReadLine() ?? "").Trim();
                switch (valasz)
                {
                    case "1": VersenyzokKiir(versenyzok); break;
                    case "2": IdoszalagKiir(); break;
                    case "3": FoglalasKezel(versenyzok, false); break;
                    case "4": FoglalasKezel(versenyzok, true); break;
                    case "5": TorlesKezel(versenyzok); break;
                    case "6": VeletlenFoglalasok(versenyzok); break;
                    case "0": fut = false; break;
                    default: Console.WriteLine("Nincs ilyen menüpont, próbáld újra."); break;
                }
            }

            Console.WriteLine();
            Fejlec();
            Console.WriteLine("A program leáll. Nyomj meg egy billentyűt a kilépéshez...");
            Console.ReadKey();
        }

        static void Fejlec()
        {
            Console.WriteLine("==================================================");
            Console.WriteLine(" Projekt neve : " + PROJEKT_NEV);
            Console.WriteLine(" Készítő      : " + KESZITO);
            Console.WriteLine(" Kezdő dátum  : " + KEZDO_DATUM);
            Console.WriteLine("==================================================");
        }

        static void HelyszinKiir(Helyszin h)
        {
            Console.WriteLine("\n--- Pálya adatai ---");
            Console.WriteLine("Név      : " + h.Nev);
            Console.WriteLine("Cím      : " + h.Cim);
            Console.WriteLine("Telefon  : " + h.Telefon);
            Console.WriteLine("Weboldal : " + h.Weboldal);
            Console.WriteLine("Nyitva   : " + NYITAS + ":00 - " + ZARAS + ":00");
            Console.WriteLine("Bérlés   : min. " + MIN_ORA + " - max. " + MAX_ORA + " óra / fő (összefüggően), "
                              + MIN_LETSZAM + "-" + MAX_LETSZAM + " fő / menet");
        }

        static void VersenyzokKiir(List<Versenyzo> lista)
        {
            Console.WriteLine();
            Console.WriteLine("{0,4} {1,-24} {2,-11} {3,-4} {4,-32} {5,-36} {6}",
                "Sz.", "Név", "Szül. idő", "18+", "Azonosító", "E-mail", "Foglalás");
            Console.WriteLine(new string('-', 135));
            for (int i = 0; i < lista.Count; i++)
            {
                Versenyzo v = lista[i];
                Console.WriteLine("{0,4} {1,-24} {2,-11} {3,-4} {4,-32} {5,-36} {6}",
                    i + 1,
                    v.TeljesNev,
                    v.SzuletesiIdo.ToString("yyyy.MM.dd"),
                    v.Elmult18 ? "igen" : "nem",
                    v.Azonosito,
                    v.Email,
                    v.FoglalasSzoveg);
            }
        }


        static void IdoszalagKiir()
        {
            Console.WriteLine("\n--- Foglalási naptár: " + napok[0].ToString("yyyy.MM.dd") + " - "
                              + napok[napok.Count - 1].ToString("yyyy.MM.dd") + " ---\n");

            Console.Write(new string(' ', 12));
            for (int h = NYITAS; h < ZARAS; h++)
                Console.Write(Kozepre(h + "-" + (h + 1), CELLA_SZELESSEG) + " ");
            Console.WriteLine();

            foreach (DateTime nap in napok)
            {
                Console.Write(nap.ToString("yyyy.MM.dd") + "  ");
                for (int h = NYITAS; h < ZARAS; h++)
                {
                    int n = naptar[nap][h].Count;
                    bool foglalt = n > 0;

                    Console.BackgroundColor = foglalt ? ConsoleColor.Red : ConsoleColor.Green;
                    Console.ForegroundColor = foglalt ? ConsoleColor.White : ConsoleColor.Black;
                    string szoveg = (foglalt && LETSZAM_KIIRAS) ? n.ToString() : "";
                    Console.Write(Kozepre(szoveg, CELLA_SZELESSEG));
                    Console.ResetColor();
                    Console.Write(" ");
                }
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.Write("Jelmagyarázat: ");
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write(" szabad ");
            Console.ResetColor();
            Console.Write("  ");
            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" foglalt ");
            Console.ResetColor();
            if (LETSZAM_KIIRAS)
                Console.Write("   (szám = foglalt létszám, max. " + MAX_LETSZAM + " fő; induláshoz min. " + MIN_LETSZAM + " fő kell)");
            Console.WriteLine();
        }

        static string Kozepre(string s, int szelesseg)
        {
            if (s.Length >= szelesseg) return s;
            int bal = (szelesseg - s.Length) / 2;
            return (new string(' ', bal) + s).PadRight(szelesseg);
        }

        // Beolvasás
        static List<string> NevekBeolvas(string fajlNev)
        {
            string ut = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fajlNev);

            if (!File.Exists(ut))
            {
                Console.WriteLine("Hiányzik a(z) " + fajlNev + " a program mappájából.");
                Console.WriteLine("Nyomj meg egy billentyűt a kilépéshez...");
                Console.ReadKey();
                Environment.Exit(1);
            }

            string tartalom = File.ReadAllText(ut, Encoding.UTF8);

            List<string> nevek = tartalom
                .Split(new char[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim().Trim('\'', '"', ' '))
                .Where(s => s.Length > 0)
                .Distinct()
                .ToList();

            Console.WriteLine("Névlista betöltve innen: " + fajlNev + " (" + nevek.Count + " elem)");
            return nevek;
        }

        // Generálás
        static Versenyzo VersenyzoGeneral(List<string> vezeteknevek, List<string> keresztnevek)
        {
            string vn = vezeteknevek[rnd.Next(vezeteknevek.Count)];
            string kn = keresztnevek[rnd.Next(keresztnevek.Count)];

            DateTime legkorabbi = DateTime.Today.AddYears(-80);
            DateTime legkesobbi = DateTime.Today.AddYears(-8);
            int napokSzama = (legkesobbi - legkorabbi).Days;
            DateTime szuletes = legkorabbi.AddDays(rnd.Next(napokSzama + 1));

            return new Versenyzo(vn, kn, szuletes);
        }

        static void NaptarLetrehoz()
        {
            DateTime ma = DateTime.Today;
            int utolsoNap = DateTime.DaysInMonth(ma.Year, ma.Month);

            for (int d = ma.Day; d <= utolsoNap; d++)
            {
                DateTime nap = new DateTime(ma.Year, ma.Month, d);
                List<Versenyzo>[] savok = new List<Versenyzo>[ZARAS];
                for (int h = NYITAS; h < ZARAS; h++)
                    savok[h] = new List<Versenyzo>();



                napok.Add(nap);
                naptar[nap] = savok;
            }
        }

        /*for (int d = 0; d < 14; d++)
                {
                    DateTime nap = ma.AddDays(d);
                    ...
                }*/

        // Foglalás
        static bool Foglal(Versenyzo v, DateTime nap, int kezdes, int hossz, out string hiba)
        {
            hiba = "";
            nap = nap.Date;

            if (hossz < MIN_ORA || hossz > MAX_ORA)
            {
                hiba = "Egy személy legalább " + MIN_ORA + ", legfeljebb " + MAX_ORA + " órát foglalhat (összefüggően).";
                return false;
            }
            if (!naptar.ContainsKey(nap))
            {
                hiba = "Csak " + napok[0].ToString("MM.dd") + ". és " + napok[napok.Count - 1].ToString("MM.dd") + ". között lehet foglalni.";
                return false;
            }
            if (kezdes < NYITAS || kezdes + hossz > ZARAS)
            {
                hiba = "A pálya " + NYITAS + ":00 és " + ZARAS + ":00 között van nyitva.";
                return false;
            }
            if (v.Foglalt)
            {
                hiba = "A versenyzőnek már van foglalása (" + v.FoglalasSzoveg + ").";
                return false;
            }
            for (int h = kezdes; h < kezdes + hossz; h++)
            {
                if (naptar[nap][h].Count >= MAX_LETSZAM)
                {
                    hiba = "A " + h + "-" + (h + 1) + " sáv betelt (max. " + MAX_LETSZAM + " fő).";
                    return false;
                }
            }

            for (int h = kezdes; h < kezdes + hossz; h++)
                naptar[nap][h].Add(v);

            v.FoglalasNap = nap;
            v.FoglalasKezdes = kezdes;
            v.FoglalasHossz = hossz;
            return true;
        }

        static void Torol(Versenyzo v)
        {
            if (!v.Foglalt) return;

            for (int h = v.FoglalasKezdes; h < v.FoglalasKezdes + v.FoglalasHossz; h++)
                naptar[v.FoglalasNap][h].Remove(v);

            v.FoglalasKezdes = -1;
            v.FoglalasHossz = 0;
        }

        static Versenyzo VersenyzoValaszt(List<Versenyzo> lista)
        {
            VersenyzokKiir(lista);
            Console.Write("\nAdd meg a versenyző azonosítóját (vagy a sorszámát, Enter = mégse): ");
            string s = (Console.ReadLine() ?? "").Trim();
            if (s.Length == 0) return null;

            Versenyzo v = lista.FirstOrDefault(x => x.Azonosito.Equals(s, StringComparison.OrdinalIgnoreCase));
            if (v == null)
            {
                int sorszam;
                if (int.TryParse(s, out sorszam) && sorszam >= 1 && sorszam <= lista.Count)
                    v = lista[sorszam - 1];
            }

            if (v == null)
                Console.WriteLine("Ilyen versenyző nincs a listában.");
            else
                Console.WriteLine("Kiválasztott versenyző: " + v.TeljesNev + " (" + v.Azonosito + "), jelenlegi foglalás: " + v.FoglalasSzoveg);
            return v;
        }

        static bool DatumBeker(out DateTime nap)
        {
            nap = DateTime.MinValue;
            Console.Write("Melyik napra? (pl. 09.26): ");
            string s = (Console.ReadLine() ?? "").Trim().TrimEnd('.');
            string[] r = s.Split('.');

            try
            {
                int ev, ho, na;
                if (r.Length == 2 && int.TryParse(r[0], out ho) && int.TryParse(r[1], out na))
                {
                    nap = new DateTime(DateTime.Today.Year, ho, na);
                    return true;
                }
                if (r.Length == 3 && int.TryParse(r[0], out ev) && int.TryParse(r[1], out ho) && int.TryParse(r[2], out na))
                {
                    nap = new DateTime(ev, ho, na);
                    return true;
                }
            }
            catch (ArgumentOutOfRangeException)
            {
            }

            Console.WriteLine("Ez nem egy érvényes dátum.");
            return false;
        }

        static bool SavBeker(out int kezdes, out int hossz)
        {
            kezdes = 0;
            hossz = 0;
            Console.Write("Melyik idősávra? (pl. 8-9 vagy 15-17): ");
            string[] r = (Console.ReadLine() ?? "").Trim().Split('-');

            int vege;
            if (r.Length == 2 && int.TryParse(r[0].Trim(), out kezdes) && int.TryParse(r[1].Trim(), out vege))
            {
                hossz = vege - kezdes;
                return true;
            }

            Console.WriteLine("Ez nem egy érvényes idősáv.");
            return false;
        }

        static void FoglalasKezel(List<Versenyzo> lista, bool atallitas)
        {
            Versenyzo v = VersenyzoValaszt(lista);
            if (v == null) return;

            if (atallitas && !v.Foglalt)
            {
                Console.WriteLine("Ennek a versenyzőnek még nincs foglalása, előbb hozz létre egyet.");
                return;
            }
            if (!atallitas && v.Foglalt)
            {
                Console.WriteLine("Ennek a versenyzőnek már van foglalása (" + v.FoglalasSzoveg + "), módosításhoz válaszd a másik menüpontot.");
                return;
            }

            DateTime nap;
            int kezdes, hossz;
            if (!DatumBeker(out nap)) return;
            if (!SavBeker(out kezdes, out hossz)) return;

            string hiba;
            if (!atallitas)
            {
                if (Foglal(v, nap, kezdes, hossz, out hiba))
                    Console.WriteLine("Foglalás rögzítve: " + v.TeljesNev + " - " + v.FoglalasSzoveg);
                else
                    Console.WriteLine("A foglalás nem hajtható végre: " + hiba);
                return;
            }

            DateTime regiNap = v.FoglalasNap;
            int regiKezdes = v.FoglalasKezdes;
            int regiHossz = v.FoglalasHossz;

            Torol(v);
            if (Foglal(v, nap, kezdes, hossz, out hiba))
            {
                Console.WriteLine("A foglalás átállítva: " + v.TeljesNev + " - " + v.FoglalasSzoveg);
            }
            else
            {
                Foglal(v, regiNap, regiKezdes, regiHossz, out hiba);
                Console.WriteLine("Az átállítás nem sikerült, a korábbi foglalás maradt érvényben (" + v.FoglalasSzoveg + ").");
            }
        }

        static void TorlesKezel(List<Versenyzo> lista)
        {
            Versenyzo v = VersenyzoValaszt(lista);
            if (v == null) return;

            if (!v.Foglalt)
            {
                Console.WriteLine("Ennek a versenyzőnek nincs aktív foglalása.");
                return;
            }

            string regi = v.FoglalasSzoveg;
            Torol(v);
            Console.WriteLine("A foglalás lemondva: " + v.TeljesNev + " (" + regi + ")");
        }

        static void VeletlenFoglalasok(List<Versenyzo> lista)
        {
            int sikeres = 0;
            foreach (Versenyzo v in lista)
            {
                if (v.Foglalt || rnd.Next(100) >= 40) continue;

                int hossz = rnd.Next(MIN_ORA, MAX_ORA + 1);
                int kezdes = rnd.Next(NYITAS, ZARAS - hossz + 1);
                DateTime nap = napok[rnd.Next(napok.Count)];
                string hiba;
                if (Foglal(v, nap, kezdes, hossz, out hiba)) sikeres++;
            }
            Console.WriteLine(sikeres + " próbafoglalás létrejött, nézd meg a naptárban.");
        }
    }
}